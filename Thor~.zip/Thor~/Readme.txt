Thanks for downloading this template!

Template Name: Thor Tugas
Template URL: https://bootstrapmade.com/free-html-bootstrap-template-Thor/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
