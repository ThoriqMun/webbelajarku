<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Tugas Desain Webku Thoriq</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/mobilku.jpg" rel="icon">
  <link href="assets/img/mobilku.jpg" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i|Playfair+Display:400,400i,500,500i,600,600i,700,700i&subset=cyrillic" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Tugas Desain Webku
  * Updated: Mar 10 2023 with Bootstrap v5.2.3
  * Template URL: https://bootstrapmade.com/free-html-bootstrap-template-Thor/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column align-items-center justify-content-center">
    <h1>Hi, I'm Thoriq Munawar</h1>
    <h2>I am a Mahasiswa STMIK KAPUTAMA</h2>
    <a href="#about me" class="btn-get-started scrollto"><i class="bi bi-chevron-double-down"></i></a>
  </section><!-- End Hero -->

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <!-- <div class="logo">
        <h1><a href="index.php">Tugasku</a></h1>
        <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>
      </div> -->

      <nav id="navbar" class="navbar">
        <ul>
          <a class="nav-link scrollto active" href="#hero">Home</a>
          <li><a class="nav-link scrollto" href="#about me">About Me</a></li>
          <li><a class="nav-link scrollto" href="#tugas 1">Tugas 1</a></li>
          <li><a class="nav-link scrollto" href="#tugas 2">Tugas 2</a></li>
          <li><a class="nav-link scrollto" href="#tugas 3">Tugas 3</a></li>
          <li><a class="nav-link scrollto" href="#tugas 4">Tugas 4</a></li>
          <li><a class="nav-link scrollto" href="#tugas 5">Tugas 5</a></li>
          <li><a class="nav-link scrollto" href="#tugas 6">Tugas 6</a></li>
          <li><a class="nav-link scrollto" href="#tugas 7">Tugas 7</a></li>
          <li><a class="nav-link scrollto" href="#tugas 8">Tugas 8</a></li>
          <li><a class="nav-link scrollto" href="#tugas 9">Tugas 9</a></li>
          <li><a class="nav-link scrollto" href="#tugas 10">Tugas 10</a></li>
          <li><a class="nav-link scrollto" href="#tugas 11">Tugas 11</a></li>
          <li><a class="nav-link scrollto" href="#tugas 12">Tugas 12</a></li>
          <li><a class="nav-link scrollto" href="#tugas 13">Tugas 13</a></li>
          <li><a class="nav-link scrollto" href="#tugas 14">Tugas 14</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      
      <!-- .navbar -->

    </div>
    <div class="container d-flex align-items-center">
      <nav id="navbar2" class="navbar">
        <ul>
        
        </ul>
      </nav>
    </div>  
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about me" class="about me">
      <div class="container">

        <div class="row no-gutters">
          <div class="image col-xl-5 d-flex align-items-stretch justify-content-center justify-content-lg-start"></div>
          <div class="col-xl-7 ps-0 ps-lg-5 pe-lg-1 d-flex align-items-stretch">
            <div class="content d-flex flex-column justify-content-center">
              <h3>Perkenalkan nama saya <br>
                Thoriq Munawar</h3>
              <div class="row">
                <div class="col-md-6 d-md-flex align-items-md-stretch">
                  <div class="count-box">
                    <i class="bi bi-emoji-smile"></i>
                    <p><strong>Impian Saya</strong> ialah menjadi seorang Developer yang Terkenal.</p>
                  </div>
                </div>

                <div class="col-md-6 d-md-flex align-items-md-stretch">
                  <div class="count-box">
                    <i class="bi bi-journal-richtext"></i>
                    <span data-purecounter-start="0" data-purecounter-end="01" data-purecounter-duration="1" class="purecounter"></span>
                    <p><strong>Saya anak pertama</strong> dari 3 bersaudara</p>
                  </div>
                </div>

                <div class="col-md-6 d-md-flex align-items-md-stretch">
                  <div class="count-box">
                    <i class="bi bi-clock"></i>
                    <span data-purecounter-start="0" data-purecounter-end="19" data-purecounter-duration="1" class="purecounter"></span>
                    <p><strong>Saya Lahir di Binjai Tepatnya tanggal 15 September 2003</strong> </p>
                  </div>
                </div>

                <div class="col-md-6 d-md-flex align-items-md-stretch">
                  <div class="count-box">
                    <i class="bi bi-award"></i>
                    <span data-purecounter-start="0" data-purecounter-end="1" data-purecounter-duration="1" class="purecounter"></span>
                    <p><strong>Idola Saya</strong> ialah Ustadz Adi Hidayat karena Beliau memiliki Pengetahuan yang Sangat Luas</p>
                  </div>
                </div>
              </div>
            </div>
            <!-- End .content-->
          </div>
        </div>

      </div>
    </section>
    <!-- End About Section -->
    <!-- ======= Tugas 1 Section ======= -->
    <section id="tugas 1" class="Tugas 1 section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Tugas 1</h2>
          <embed id="tugas1"src="thoriq tugas1.pdf#toolbar=0&navpanes=0&scrollbar=0" type="application/pdf" width="100%" height="600px" />
      </div>
    </section>
    <!-- End Tugas 1 Section -->

    <!-- ======= Tugas 2 Section ======= -->
    <section id="tugas 2" class="Tugas 2 section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Tugas 2</h2>
          <embed id="tugas2"src="thoriq tugas2.pdf#toolbar=0&navpanes=0&scrollbar=0" type="application/pdf" width="100%" height="600px" />
    </section>
    <!-- End Tugas 2 Section -->

    <!-- ======= Tugas 3 Section ======= -->
    <section id="tugas 3" class="Tugas 3 section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Tugas 3</h2>
          <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Foodcourt</title>
            <link rel="stylesheet" href="css/style.css">
        </head>
        
        <body>
            <header>
                <h1>Foodcourt</h1>
                <img src="assets/img/logo.png" alt="Gambar Foodcourt" width="150px">
            </header>
            <main>
                <h2>Daftar Menu Makanan</h2>
                <table border="1">
                    <thead>
                        <tr>
                            <th>Nama Makanan</th>
                            <th>Harga</th>
                            <th>Gambar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Nasi Goreng Special</td>
                            <td>Rp 35.000</td>
                            <td>
                                <img src="assets/img/nasigoreng.webp" alt="Gambar Nasi Goreng" width="250px"><br>
                                <a href="nasigoreng.html">Lihat selengkapnya</a>
                            </td>
                        </tr>
                        <tr>
                            <td>Mie Goreng</td>
                            <td>Rp 10.000</td>
                            <td>
                                <img src="assets/img/miegoreng.png" alt="Gambar Mie Ayam" width="250px"><br>
                                <a href="miegoreng.html">Lihat selengkapnya</a>
                            </td>
                        </tr>
                        <tr>
                            <td>Sate Padang</td>
                            <td>Rp 10.000</td>
                            <td>
                                <img src="assets/img/satepadang.png" alt="Gambar Sate Padang" width="250px"><br>
                                <a href="satepadang.html">Lihat selengkapnya</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </main>
            <footer>
                <p>&copy; Thoriq Munawar</p>
            </footer>
        </body>
    </section><!-- Tugas 3 Section -->

    <!-- ======= Tugas 4 Section ======= -->
    <section id="tugas 4" class="Tugas 4 section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Tugas 4</h2>
          <html>
<head>
  <style>
      p{
        text-align: justify;
      }

      #box{
        
        width: 1000px;
        height: auto;
        margin: auto;
      }

      #header1{
        background-color: #dfd5d5;
        padding: 20px;
      }

      #menubar1{
        background-color: #e4e4e4;
        margin: auto;
      }

      .teksmenu{
        text-decoration: none;
      }

      #konten1{
        padding: 20px;
      }

      #footer1{
        background-color: #999494;
        padding: 20px;
      }
  </style>
</head>
<body>
	<div id="box">
		<div id="header1" align="center">
			<h1>STMIK Kaputama Binjai</h1>
			Jl. Veteran No.4A, Tangsi, Kec. Binjai Kota, Kota Binjai, Sumatera Utara 20714
		</div>
		<br><div id="menubar1" align="center">
			<a href="" class="teksmenu">Home</a> | <a href="">Beranda</a> | <a href="">Produk</a>
		</div>
		<div id="konten1">
			<br>
      <p>
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. In finibus urna massa, vel varius lectus ullamcorper nec. Vivamus ornare massa non odio faucibus vehicula. Sed luctus nisi ut laoreet interdum. Sed eu sem ut felis tristique commodo. Morbi nec egestas orci. Donec ornare rhoncus facilisis. Suspendisse lacinia justo sit amet enim lobortis, sed blandit sapien ultricies. Donec pharetra tincidunt libero vel tincidunt. Phasellus rhoncus condimentum augue, ullamcorper gravida enim ultricies molestie. Aenean arcu enim, maximus feugiat semper ut, blandit eget ex. Integer eget sollicitudin risus, id varius est. Nam ac interdum nisi. Nam sit amet dui vel dui sagittis posuere. Sed pulvinar tortor nec nisi placerat semper. Praesent neque lacus, dictum quis nisi id, tempus gravida turpis. Ut sit amet vulputate elit.
			</p>
			
		</div>
		<div id="footer1" align="center">
			Web Programming I <br> 2018
		</div>
		</div>

</body>    
    </section>
    <!-- End Tugas 4 Section -->

    <!-- ======= Tugas 5 Section ======= -->
    <section id="tugas 5" class="Tugas 5 section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Tugas 5</h2>
          <hr>
          <h3><ul>Part 1</ul></h3>
          <?php 
            $a="5"; 
            $b="2.5"; 
            $komentar="Selamat Datang"; 
            echo ("<t>Nilai variabel a adalah = $a <br>"); 
            //variabel bertipe integer 
            echo ("Nilai variabel b adalah = $b <br>"); 
            //variabel bertipe real 
            echo ("Nilai variabel komentar adalah = $komentar<br>"); 
            //variabel bertipe string 
            $tambah= $a + $b; 
            //rumus pengurangan
            $kurang = $a - $b;
            //rumus perkalian
            $kali = $a * $b;
            //rumus pembagian
            $bagi = $a / $b;

            echo ("Hasil penjumlahan a dan b adalah = $tambah <br>");  
            echo ("Hasil pengurangan a dan b adalah = $kurang<br>"); 
            echo ("Hasil perkalian a dan b adalah = $kali <br>"); 
            echo ("Hasil pembagian a dan b adalah = $bagi <br>"); 
            $nama = "STIKI"; 
            $garis= "====================================="; 
            echo "<p>"; 
            echo $garis."<br>"; 
            echo $komentar. " Di Lab ". $nama. "<br>Selamat Belajar Pemrograman Web <br>"; 
            echo $garis."<br>"; 
          ?>
          <hr><br>
          <h3><ul>Part 2</ul></h3>
          <br>
          <?php
              $nim = '1710110989';
              $nama = 'Maria Mercedes';
              $alamat = 'Jl. Gajah Mada No.4';
              $nilai = 80;

              echo "NIM : ", $nim, "<br>";

              echo "Nama : ", $nama, "<br>";
              echo "Alamat : ", $alamat, "<br>";

              echo "Nilai : $nilai";
          ?>  
        </section>
    <!-- End Tugas 5 Section -->

    <!-- ======= Tugas 6 Section ======= -->
    <section id="tugas 6" class="Tugas 6 section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Tugas 6</h2>
          <hr>
          <h3><ul>Part 1</ul></h3>
          <?php
              $bil = 1;
              while($bil <= 3){
                echo "Nilai Sekarang adalah $bil <br>";
                $bil++;
                }
          ?>
          <br><hr>
          <h3><ul>Part 2</ul></h3>
          <?php
            $bil = 5;
            while ($bil <= 100)
            {
              if ($bil % 10 == 0) echo $bil. "<br />";
              $bil++;
            }
          ?>
          <br><hr>
          <h3><ul>Part 3</ul></h3>
          <?php
            $bilangan = 0;
            for ($a=1; $a<=5; $a++){
              echo "Bilangan Sekarang adalah $bilangan <br>"; $bilangan = $bilangan + $a;
            }
          ?> 
          <hr> 
          
        </section><!-- End Tugas 6 Section -->

        <!-- ======= Tugas 7 Section ======= -->
    <section id="tugas 7" class="Tugas 7 section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Tugas 7</h2>
          <hr>
          <h3><ul>Part 1</ul></h3>
          <?php
            $kelompok1 =
            array("Andi","Budi","Chika","David","Erna"); echo "Nama Kelompok 1 :<br />";
            for ($i=0; $i<=4; $i++){
            echo " + ",$kelompok1[$i],"<br/>";
            }

            echo"<br /><br />";

            $kelompok2[] = "Fera";

            $kelompok2[] = "Gani";
            $kelompok2[] = "Hery";
            $kelompok2[] = "Intan";
            $kelompok2[] = "Jaka";

            echo "Nama Kelompok 2 :<br />";
            for ($i=0; $i<=4; $i++){
            echo " + ",$kelompok2[$i],"<br/>";
            }
          ?>
          <br><hr>
          <h3><ul>Part 2</ul></h3>
          <?php
            $array1 = array ("Arman","Bayu","Feri"); echo"array awal ialah:<br/>";
            for ($i=0; $i<count($array1); $i++){
            echo"data ke-",$i," : ",$array1[$i],"<br/>";
            }
            echo "<br/>Setlah ditambahkan \"Herni, Gita & Dewi\" menggunakan fungsi array_push():<br/>";
            array_push($array1,"Herni","Gita","Dewi"); for ($i=0; $i<count($array1); $i++){
            echo"data ke-",$i," : ",$array1[$i],"<br/>";
            }
            echo "<br/>Setlah bagian awal array dihapus menggunakan fungsi array_shift():<br/>";
            array_shift($array1);
            for ($i=0; $i<count($array1); $i++){
            echo"data ke-",$i," : ",$array1[$i],"<br/>";
            }
            echo "<br/>Dan setelah isi array diurutkan menggunakan fungsi sort():<br/>";
            sort($array1);
            for ($i=0; $i<count($array1); $i++){
            echo"data ke-",$i," : ",$array1[$i],"<br/>";
            }
          ?>    

        </section>
        <!-- End Tugas 7 Section -->

        <!-- ======= Tugas 8 Section ======= -->
    <section id="tugas 8" class="Tugas 8 section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Tugas 8</h2>
          <h2>Libur UTS NGAB</h2>
        </section>
        <!-- End Tugas 8 Section -->

        <!-- ======= Tugas 9 Section ======= -->
    <section id="tugas 9" class="Tugas 9 section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Tugas 9</h2>
          <div class="card kartu">
            <div class="row">
                <div class="col-md-4">
                    <div class="foto">
                        <img src="assets/img/fhoto me.jpeg"
                            class="img-thumbnail" alt="" width="300" height="auto" style="background: rgb(233, 78, 78);">
                    </div>
                </div>
                <div class="col-md-8 kertas-biodata">
                    <div class="biodata">
                        <table width="100%" border="0" style="color: rgb(90, 168, 204)">
                            <tbody>
                                <tr>
                                    <td valign="top">
                                        <table border="0" width="100%"
                                            style="padding-left: 0px; padding-right: 11px;">
                                            <tbody>
                                                <tr>
                                                    <td width="25%" valign="top" class="textt">Nama</td>
                                                    <td width="2%">:</td>
                                                    <td style="color: #b31119; font-weight:bold">Thoriq Munawar</td>
                                                </tr>
                                                <tr>
                                                    <td class="textt">Jenis Kelamin</td>
                                                    <td>:</td>
                                                    <td>Laki-Laki</td>
                                                </tr>
                                                <tr>
                                                    <td class="textt">Tempat Lahir</td>
                                                    <td>:</td>
                                                    <td>Medan</td>
                                                </tr>
                                                <tr>
                                                    <td class="textt">Tanggal Lahir</td>
                                                    <td>:</td>
                                                    <td>15-09-2003</td>
                                                </tr>
                                                <tr>
                                                    <td class="textt">Fakultas</td>
                                                    <td>:</td>
                                                    <td>Teknik</td>
                                                </tr>
                                                <tr>
                                                    <td valign="top" class="textt">Prodi</td>
                                                    <td valign="top">:</td>
                                                    <td>Teknik Informatika</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div> <br><br><br><div style="border-bottom:3px dashed #00f;"></div>
    <div class="row mt-5 mb-5">
        <div class="col">
            <h2 class="mb-5">Moto</h2>
        <h4>Hidup harus Berani Seperti Larry</h4>
        </div>
        <div class="col">
            <iframe width="460" height="275" src="https://www.youtube.com/embed/u5CVsCnxyXg"
                title="YouTube video player" frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowfullscreen></iframe>

        </div>
    </div>
    <div style="border-bottom:3px dashed #00f;"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-6 mt-5">

                <div class="slider-container">
                    <div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active" data-bs-interval="1000">
                                <img src="assets/img/1.jpg" class="d-block w-50" alt="..." />
                            </div>
                            <div class="carousel-item" data-bs-interval="1000">
                                <img src="assets/img/2.jpg" class="d-block w-50" alt="..." />
                            </div>
                            <div class="carousel-item" data-bs-interval="1000">
                                <img src="assets/img/3.jpg" class="d-block w-50" alt="..." />
                            </div>
                            <div class="carousel-item" data-bs-interval="1000">
                                <img src="assets/img/4.jpeg" class="d-block w-50" alt="..." />
                        </div>
                        <div class="carousel-item" data-bs-interval="1000">
                            <img src="assets/img/1.jpg" class="d-block w-50" alt="..." />
                    </div>
                </div>
            </div>
        </div>
    </div>
   <h2>Hidup Seperti Larry</h2>
</ul>
</div>

        </section><!-- End Tugas 9 Section -->

        <!-- ======= Tugas 10 Section ======= -->
    <section id="tugas 10" class="Tugas 10 section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Tugas 10</h2>
          <li class="nav-item"> <a class="nav-link" href="pert10.php"></a></li>
          <div class="row">

<!-- Area Chart -->
<div class="col-xl-8 col-lg-7">
    <div class="card shadow mb-4">
        <!-- Card Header - Dropdown -->
        <div
            class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Earnings Overview</h6>
            <div class="dropdown no-arrow">
                <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                    aria-labelledby="dropdownMenuLink">
                    <div class="dropdown-header">Dropdown Header:</div>
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Something else here</a>
                </div>
            </div>
        </div>
        <!-- Card Body -->
        <div class="card-body">
            <div class="chart-area">
                <canvas id="myAreaChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Pie Chart -->
<div class="col-xl-4 col-lg-5">
    <div class="card shadow mb-4">
        <!-- Card Header - Dropdown -->
        <div
            class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Revenue Sources</h6>
            <div class="dropdown no-arrow">
                <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                    aria-labelledby="dropdownMenuLink">
                    <div class="dropdown-header">Dropdown Header:</div>
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Something else here</a>
                </div>
            </div>
        </div>
        <!-- Card Body -->
        <div class="card-body">
            <div class="chart-pie pt-4 pb-2">
                <canvas id="myPieChart"></canvas>
            </div>
            <div class="mt-4 text-center small">
                <span class="mr-2">
                    <i class="fas fa-circle text-primary"></i> Direct
                </span>
                <span class="mr-2">
                    <i class="fas fa-circle text-success"></i> Social
                </span>
                <span class="mr-2">
                    <i class="fas fa-circle text-info"></i> Referral
                </span>
            </div>
        </div>
    </div>
</div>
</div>

        <!-- End Tugas 10 Section -->

        <!-- ======= Tugas 11 Section ======= -->
    <section id="tugas 11" class="Tugas 11 section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Tugas 11</h2>
          <h1>
            <ul>
              <li>Tidak Ada Tugas Praktikum Karena Zoom !!</li>
            </ul>
          </h1>
  
        <!-- End Tugas 11 Section -->

        <!-- ======= Tugas 12 Section ======= -->
    <section id="tugas 12" class="Tugas 12 section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Tugas 12</h2>
          <h1>
            <ul>
              <li>Tidak Ada Tugas Praktikum Karena Zoom !!</li>
            </ul>
          </h1>
  
        <!-- End Tugas 12 Section -->

        <!-- ======= Tugas 13 Section ======= -->
    <section id="tugas 13" class="Tugas 13 section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Tugas 13</h2>  
          <div class="#">
                        <hr>

                        <div class="#">

                            <h3><li>Petani Kode Javascript :</li></h3>
                            <h5>Part 1 : Introduction</h5>
                            <script>
                              console.log("I'm Learning Javascript ツ")
                              document.write("<t>Hello World ツ <br>")
                            </script>
                            <br>
                            <h5>Part 2 : Writting</h5>
                            <script>
                              console.log("Hi, This Is a javascript Code ツ")
                              document.write("Javascript Is Cool ツ <br>")
                            </script>
                            <br>
                            <h5>Part 3 : Output At Javascript</h5>
                            <script>
                              console.log("Hello World! ツ")
                              
                              function sayHello(){
                                alert("Hello World! ツ")
                              }
                            </script>
                            <button onclick="sayHello()">Click Me ツ</button>
                            <script>
                              document.write("<br>I'm Learning Javascript ツ")
                            </script>
                            <div id="output-result"></div>
                            <script>
                              var result = document.getElementById("output-result")
                              result.innerHTML = "<p>I Like Javascript ツ</p>"
                            </script>
                            <br>
                            <h5>Part 4 : Variable & Data Type</h5>
                            <script>
                              var name = "Petani Kode"
                              var visitorCount = 50322
                              var isActive = true
                              var url = "https://www.petanikode.com"
          
                              function sayHi(){
                                alert("Module From " + name)
                              }
                            </script>
                            <button onclick="sayHi()">Click Me ツ</button>
                            <script>
                              document.write("<br>Module From    : " + name + "<br>")
                              document.write("Visitors Count : " + visitorCount + "<br>")
                              document.write("Active Status  : " + isActive + "<br>")
                              document.write("URL Address : " + url + "<br>")
                            </script>
                            <br>
                            <h5>Part 5 : Dialog Windows For Input</h5>
                            <button onclick="alert('This is From Alert')">Click Me ツ (Alert)</button>
                            <br>
                            <button onclick="confirm('Wanna Go To PetaniKode ? ツ')">Click Me ツ (Confirm)</button>
                            <br>
                            <button onclick="prompt('What Is Your Name ? ツ', '')">Click Me ツ (Prompt)</button>
                            <br>
                            <br>
                            <!-- <Script>
                              var sure = confirm("Wanna Go To PetaniKode ? ツ")
          
                              if (sure) {
                                window.location = "https://www.petanikode.com"
                              } else {
                                document.write("<br>Aight Then, Stay Here Yeah ツ")
                              }
                              var name = prompt("What's Your Name ? ツ", "")
                              document.write("<p> Hello " + name + "</p>")
                            </Script> -->
                            <h5>Part 6 : Operator</h5>
                            <script>
                              var a = 599
                              var b = 69
                              var c = 0
          
                              c = a - b
                              document.write(`<br>${a} - ${b} = ${c}<br>`)
                              c = a + b
                              document.write(`<br>${a} + ${b} = ${c}<br>`)
                              c = a * b
                              document.write(`<br>${a} * ${b} = ${c}<br>`)
                              c = a / b
                              document.write(`<br>${a} / ${b} = ${c}<br>`)
                              c = a ** b
                              document.write(`<br>${a} ** ${b} = ${c}<br>`)
                              c = a % b
                              document.write(`<br>${a} % ${b} = ${c}<br>`)
                            </script>
                            <br>
                            <h5>Part 7 : Branching (Logic/Condition)</h5>
                            <br>
                            <script>
                              document.write("<p> In Order To See The Result, Please Un-Comment It From The Code !! ツ")
                              // var shopAmount = prompt("Shopping Amount ? ツ", "")
                              if (shopAmount > 100000) {
                                document.write("<p>Congratulations, You've Win a Prize !! ツ</p>")
                              } else {
                                document.write("<p>Good Luck Next Time, Bud !! ツ</p>")
                              }
                              document.write("<p>Thanks For Visiting !! ツ</p>")
                            </script>
                            <br>
                            <h5>Part 8 : Looping</h5>
                            <br>
                            <script>
                              for (let i = 0; i < 5; i++) {
                                document.write("<p>Looping -" + i + "</p>")  
                              }
                              document.write("<p> In Order To See 'While' Result, Please Un-Comment It From The Code !! ツ")
                              // var retry = confirm("Do You Wanna Retry ?")
                              // var counter  = 0;
                              // while (retry) {
                              //   counter++;
                              //   retry = confirm("Do You Wanna Retry ?")
                              // }
                            </script>
                            <br>
                            <h5>Part 9 : Array</h5>
                            <br>
                            <script>
                              var nyeh = ["Goo","Goo","Gah","Gah"]
          
                              document.write(nyeh[0] + "<br>")
                              document.write(nyeh[1] + "<br>")
                              document.write(nyeh[2] + "<br>")
                              document.write(nyeh[3] + "<br>")
                            </script>
                            <br>
                            <h5>Part 10 : Function</h5>
                            <br>
                            <script>
                              var salam = () => alert("Assalamualaikum ツ")
                            </script>
                            <a href="#" onclick="salam()">Click Me ツ</a>
                            <br><br>
                            <h5>Part 11 : Object In Js</h5>
                            <br>
                            <script>
                              var person = {
                                firstName : "Lebowski ",
                                middleName : "de ",
                                lastName : "Chivar",
                                showname : function() {
                                  document.write(`Name : ${this.firstName} ${this.middleName} ${this.lastName}`)
                                }
                              }
                              person.showname()
                              document.write("For More Information About The Code, You Can Check It By Yourseelf ツ")
                            </script>
                      </div>
                    </div>
                  <hr>
                </div>
</section>
        <!-- End Tugas 13 Section -->

        <!-- ======= Tugas 14 Section ======= -->
    <section id="tugas 14" class="Tugas 14 section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Tugas 14</h2>
          <h3><li>First Part : </li></h3>
                <hr>  
                <script>
                  document.write("<t>Learning Javascript Programming ! ツ")
                </script>
                <hr>
                <B>First Part Is From HTML</B>
                <p>
                <script>
                  document.write("<t><br>This Part Is From Javascript")
                </script>
                <p>  
                <B>The Last Part, Also  Written In HTML, After Script</B>
                <hr>
  
                <style tugas 14>
                  #box {
                    background: #fff;
                  }
                </style>
  
                <div id="box">
                  <script>
                    document.writeln("<PRE>")
                    document.write("<B><FONT SIZE = 5>")
                    document.writeln("Welcome To Javascript")
                    document.write("</B><>/FONT")
                    document.write("<I>")
                    document.writeln("This Is a Simple Example Of Showing Text ! ツ")
                    document.write("<I>")
                    document.writeln("Using Javascript ! ツ")  
                  </script>
                  <hr>
                </div>
          
        <!-- End Tugas 14 Section -->
  </main>
  <!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>~Thor~</span></strong>. 
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/free-html-bootstrap-template-Thor/ -->
        Dibuat Oleh <a href="https://bootstrapmade.com/">Thoriq Munawar</a>
      </div>
    </div>
  </footer><!-- End  Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="assets/js/dashboards-analytics.js"></script>

  <!-- Bootstrap core JavaScript-->
  <script src="aset/vendor/jquery/jquery.min.js"></script>
    <script src="aset/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="aset/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="aset/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="aset/vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="aset/js/demo/chart-area-demo.js"></script>
    <script src="aset/js/demo/chart-pie-demo.js"></script>
</body>
</html>